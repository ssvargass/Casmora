/**
 * @file
 * Javascript for Geolocation Field.
 */
